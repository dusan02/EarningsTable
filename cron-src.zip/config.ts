// Re-export shared config
export { CONFIG, validateConfig, validatePolygonConfig, todayIsoNY } from '../../shared/src/config.js';
